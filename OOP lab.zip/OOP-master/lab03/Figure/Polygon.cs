﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figure
{
    public enum Polygon
    {
        Triangle = 3,
        Quadrilateral = 4,
        Pentagon = 5
    }
}
